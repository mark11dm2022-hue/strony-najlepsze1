// ---- Mobilne menu ----
function toggleMenu(){document.getElementById('navLinks').classList.toggle('open');}

// ---- FAQ ----
document.addEventListener('click',function(e){
  var q=e.target.closest('.faq-q');
  if(q){q.parentElement.classList.toggle('open');}
});

// ---- Zakladki (pomoc) ----
function openTab(id,btn){
  document.querySelectorAll('.tab-panel').forEach(function(p){p.classList.remove('active');});
  document.querySelectorAll('.tab-btn').forEach(function(b){b.classList.remove('active');});
  var el=document.getElementById(id);
  if(el)el.classList.add('active');
  if(btn)btn.classList.add('active');
}

// ---- Prosty asystent AI (dziala lokalnie, bez wysylania danych) ----
var KB=[
  {k:['ile','kosztuje','cena','cennik','koszt','zaplacic'],a:'Ceny zalezą od wielkości projektu: maly projekt od 150 zl, średni od 250 zl, a zlozony od 600 zl wzwyż. Dokladną wycenę przygotuję po poznaniu Twoich potrzeb — napisz na mark11dm2022@gmail.com.'},
  {k:['hosting','domena','domen','serwer'],a:'Projekt strony placisz jednorazowo. Hosting i domenę oplaca bezpośrednio klient (zwykle 50-150 zl rocznie za domenę i hosting). Dzięki temu masz pelną kontrolę nad swoją stroną i jej odnowieniem.'},
  {k:['czas','ile trwa','trwa','dlugo','termin','kiedy','szybko','gotowe','realizacja'],a:'Maly projekt realizuję zwykle w 2-4 dni, średni w 5-8 dni, a zlozony w 2-3 tygodnie. Dokladny termin ustalamy przed startem.'},
  {k:['kontakt','napisac','email','mail'],a:'Najlepiej napisz na e-mail: mark11dm2022@gmail.com — odpowiadam zwykle tego samego dnia. Formularz kontaktowy znajdziesz też w zakladce Kontakt.'},
  {k:['oferuje','oferta','robisz','uslugi','zajmujesz'],a:'Tworzę mini-strony dla firm: strony wizytówki, proste landing page, menu dla restauracji, portfolio itp. Szybko, nowocześnie i w rozsądnej cenie.'},
  {k:['zmiana','zmiany','poprawki','edycja','aktualizacja'],a:'Drobne poprawki po oddaniu projektu są mile widziane. Większe zmiany i rozbudowę rozliczam osobno — zawsze ustalamy to wcześniej.'},
  {k:['platnosc','zaplata','faktura','przelew','jak placic'],a:'Platność przelewem — zazwyczaj 50% zaliczki na start i 50% po oddaniu projektu. Szczególy ustalamy indywidualnie.'},
  {k:['mobilny','telefon','telefonie','responsywna','komorka','dziala'],a:'Tak — każda strona jest w pelni responsywna i dziala idealnie na telefonie, tablecie i komputerze.'},
  {k:['seo','google','wyszukiwarka'],a:'Strony przygotowuję z podstawową optymalizacją pod Google (tytuly, opisy, szybkość ladowania). Rozbudowane SEO mogę wycenić osobno.'},
  {k:['dziekuje','dzieki','super'],a:'Cala przyjemność po mojej stronie! Jeśli masz jeszcze pytania — śmialo pytaj albo napisz na mark11dm2022@gmail.com.'},
  {k:['czesc','hej','witam','dzien dobry','hello'],a:'Cześć! Jestem asystentem, który pomoże Ci szybko rozwiązać proste pytania o moje uslugi. O co chcesz zapytać?'}
];

function escapeHtml(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML;}

// Usuwa polskie znaki diakrytyczne, aby dopasowanie dzialalo niezaleznie od pisowni
function norm(s){
  return s.toLowerCase()
    .replace(/ą/g,'a').replace(/ć/g,'c').replace(/ę/g,'e').replace(/ł/g,'l')
    .replace(/ń/g,'n').replace(/ó/g,'o').replace(/ś/g,'s')
    .replace(/ż/g,'z').replace(/ź/g,'z');
}

function botReply(text){
  var t=norm(text);
  var best=null,score=0;
  KB.forEach(function(item){
    var s=0;
    item.k.forEach(function(kw){if(t.indexOf(norm(kw))!==-1)s++;});
    if(s>score){score=s;best=item;}
  });
  if(best&&score>0)return best.a;
  return 'Nie jestem pewien, czy dobrze zrozumialem. Spróbuj zapytać o cenę, hosting, czas realizacji albo kontakt. W trudniejszych sprawach napisz na mark11dm2022@gmail.com — odpowiem osobiście.';
}

function addMsg(txt,who){
  var body=document.getElementById('chatBody');
  var div=document.createElement('div');
  div.className='msg '+who;
  div.innerHTML=escapeHtml(txt);
  body.appendChild(div);
  body.scrollTop=body.scrollHeight;
}

function sendMsg(preset){
  var input=document.getElementById('chatInput');
  var val=preset||input.value.trim();
  if(!val)return;
  addMsg(val,'user');
  if(!preset)input.value='';
  setTimeout(function(){addMsg(botReply(val),'bot');},420);
}

function chatKey(e){if(e.key==='Enter')sendMsg();}

// ---- Formularz kontaktowy -> mailto ----
function sendForm(e){
  e.preventDefault();
  var n=document.getElementById('fName').value;
  var em=document.getElementById('fEmail').value;
  var m=document.getElementById('fMsg').value;
  var subject=encodeURIComponent('Zapytanie o strone — '+n);
  var bodyTxt=encodeURIComponent('Imie: '+n+'\nE-mail: '+em+'\n\n'+m);
  window.location.href='mailto:mark11dm2022@gmail.com?subject='+subject+'&body='+bodyTxt;
  return false;
}

// ---- Toast / powiadomienia ----
function toast(msg, type){
  var t=document.createElement('div');
  t.className='toast '+(type||'ok');
  t.textContent=msg;
  document.body.appendChild(t);
  requestAnimationFrame(function(){t.classList.add('show');});
  setTimeout(function(){t.classList.remove('show');setTimeout(function(){t.remove();},350);},3800);
}

// ---- Pomocnik fetch JSON ----
async function apiPost(url, data){
  var r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
  var j=await r.json().catch(function(){return {};});
  return {ok:r.ok, data:j};
}
async function apiGet(url){
  var r=await fetch(url);
  var j=await r.json().catch(function(){return {};});
  return {ok:r.ok, data:j};
}
