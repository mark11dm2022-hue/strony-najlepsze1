// Kalendarz rezerwacji + wysylka rezerwacji.
(function () {
  var MONTHS = ['stycze\u0144','luty','marzec','kwiecie\u0144','maj','czerwiec','lipiec','sierpie\u0144','wrzesie\u0144','pa\u017adziernik','listopad','grudzie\u0144'];
  var DOWS = ['Pn','Wt','\u015ar','Cz','Pt','So','Nd'];

  var today = new Date(); today.setHours(0,0,0,0);
  var view = new Date(today.getFullYear(), today.getMonth(), 1);
  var selDate = null, selTime = null;

  var calTitle = document.getElementById('calTitle');
  var calDows = document.getElementById('calDows');
  var calDays = document.getElementById('calDays');
  var slotsBox = document.getElementById('slotsBox');
  var pickInfo = document.getElementById('pickInfo');

  DOWS.forEach(function (d) { var el = document.createElement('div'); el.className = 'dow'; el.textContent = d; calDows.appendChild(el); });

  function fmt(d) {
    var m = String(d.getMonth() + 1).padStart(2, '0');
    var day = String(d.getDate()).padStart(2, '0');
    return d.getFullYear() + '-' + m + '-' + day;
  }

  function renderCal() {
    calTitle.textContent = MONTHS[view.getMonth()] + ' ' + view.getFullYear();
    calDays.innerHTML = '';
    var first = new Date(view.getFullYear(), view.getMonth(), 1);
    var startDow = (first.getDay() + 6) % 7; // poniedzialek = 0
    var daysInMonth = new Date(view.getFullYear(), view.getMonth() + 1, 0).getDate();
    var maxDate = new Date(today); maxDate.setDate(maxDate.getDate() + 60);

    for (var i = 0; i < startDow; i++) {
      var e = document.createElement('div'); e.className = 'cal-day muted'; calDays.appendChild(e);
    }
    for (var day = 1; day <= daysInMonth; day++) {
      var d = new Date(view.getFullYear(), view.getMonth(), day);
      var btn = document.createElement('button');
      btn.type = 'button'; btn.className = 'cal-day'; btn.textContent = day;
      var dow = d.getDay();
      var disabled = d < today || d > maxDate || dow === 0 || dow === 6;
      if (disabled) { btn.disabled = true; }
      else {
        (function (dd) { btn.addEventListener('click', function () { selectDay(dd, btn); }); })(d);
      }
      if (selDate && fmt(d) === selDate) btn.classList.add('sel');
      calDays.appendChild(btn);
    }
    // przyciski nawigacji
    var prevLimit = new Date(today.getFullYear(), today.getMonth(), 1);
    document.getElementById('prevM').disabled = (view <= prevLimit);
  }

  function selectDay(d, btn) {
    selDate = fmt(d); selTime = null;
    document.querySelectorAll('.cal-day.sel').forEach(function (x) { x.classList.remove('sel'); });
    btn.classList.add('sel');
    updatePick();
    loadSlots();
  }

  function updatePick() {
    pickInfo.textContent = selDate ? (selDate + (selTime ? ', godz. ' + selTime : '')) : '\u2014';
  }

  async function loadSlots() {
    slotsBox.innerHTML = '<p class="slots-empty">\u0141adowanie godzin\u2026</p>';
    var r = await apiGet('/api/slots?date=' + encodeURIComponent(selDate));
    var slots = (r.data && r.data.slots) || [];
    if (!slots.length) {
      slotsBox.innerHTML = '<p class="slots-empty">Brak wolnych godzin w tym dniu. Wybierz inny termin.</p>';
      return;
    }
    var wrap = document.createElement('div'); wrap.className = 'slots';
    slots.forEach(function (h) {
      var s = document.createElement('button');
      s.type = 'button'; s.className = 'slot'; s.textContent = h;
      s.addEventListener('click', function () {
        selTime = h;
        wrap.querySelectorAll('.slot.sel').forEach(function (x) { x.classList.remove('sel'); });
        s.classList.add('sel');
        updatePick();
      });
      wrap.appendChild(s);
    });
    slotsBox.innerHTML = '<label style="display:block;color:var(--muted);font-size:.9rem;margin-bottom:8px">Wybierz godzin\u0119:</label>';
    slotsBox.appendChild(wrap);
  }

  document.getElementById('prevM').addEventListener('click', function () {
    view = new Date(view.getFullYear(), view.getMonth() - 1, 1); renderCal();
  });
  document.getElementById('nextM').addEventListener('click', function () {
    view = new Date(view.getFullYear(), view.getMonth() + 1, 1); renderCal();
  });

  // Wysylka rezerwacji
  document.getElementById('bookForm').addEventListener('submit', async function (e) {
    e.preventDefault();
    var box = document.getElementById('bookMsg'); box.innerHTML = '';
    function esc(s){var d=document.createElement('div');d.textContent=s||'';return d.innerHTML;}
    if (!selDate || !selTime) {
      box.innerHTML = '<div class="msgbox err">Najpierw wybierz dzie\u0144 i godzin\u0119 rozmowy.</div>';
      return;
    }
    var btn = document.getElementById('bookBtn'); btn.disabled = true;
    var payload = {
      firstName: document.getElementById('bFirst').value,
      lastName: document.getElementById('bLast').value,
      email: document.getElementById('bEmail').value,
      date: selDate, time: selTime,
      topic: document.getElementById('bTopic').value,
      message: document.getElementById('bMsg').value,
    };
    var res = await apiPost('/api/bookings', payload);
    btn.disabled = false;
    if (res.ok) {
      box.innerHTML = '<div class="msgbox ok">' + esc(res.data.message || 'Sprawd\u017a e-mail i potwierd\u017a rezerwacj\u0119.') + '</div>';
      toast('Wys\u0142ali\u015bmy link potwierdzaj\u0105cy na Tw\u00f3j e-mail.', 'ok');
      e.target.reset(); selTime = null; loadSlots(); updatePick();
    } else {
      box.innerHTML = '<div class="msgbox err">' + esc((res.data && res.data.error) || 'Nie uda\u0142o si\u0119 zarezerwowa\u0107. Spr\u00f3buj ponownie.') + '</div>';
      if (res.data && res.data.error && /zaj\u0119ty/i.test(res.data.error)) loadSlots();
    }
  });

  // Banner po potwierdzeniu e-maila
  (function () {
    var p = new URLSearchParams(location.search).get('confirm');
    if (!p) return;
    var b = document.getElementById('confirmBanner');
    if (p === 'ok') b.innerHTML = '<div class="msgbox ok">\u2705 Dzi\u0119kujemy! Twoja rezerwacja zosta\u0142a potwierdzona. Do zobaczenia na rozmowie!</div>';
    else if (p === 'invalid') b.innerHTML = '<div class="msgbox err">Link potwierdzaj\u0105cy jest nieprawid\u0142owy lub wygas\u0142. Zarezerwuj termin ponownie.</div>';
  })();

  renderCal();
})();
