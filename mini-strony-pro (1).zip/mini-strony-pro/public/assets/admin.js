// Panel administratora: logowanie + zarzadzanie rezerwacjami i opiniami.
function esc(s){var d=document.createElement('div');d.textContent=s==null?'':s;return d.innerHTML;}

var STATUS_PL = {
  pending_email: 'Oczekuje na potwierdzenie',
  confirmed: 'Potwierdzona',
  cancelled: 'Anulowana',
  rejected: 'Odrzucona',
  done: 'Zrealizowana',
};

async function adminLogout() {
  await apiPost('/api/admin/logout', {});
  location.reload();
}

function showDash(email) {
  document.getElementById('loginView').style.display = 'none';
  document.getElementById('dashView').style.display = 'block';
  document.getElementById('logoutLink').style.display = 'inline-block';
  document.getElementById('adminEmail').textContent = email || '';
  loadBookings();
  loadReviews();
}

async function checkAuth() {
  var r = await apiGet('/api/admin/me');
  if (r.data && r.data.authenticated) showDash(r.data.email);
}

async function loadBookings() {
  var r = await apiGet('/api/admin/bookings');
  var body = document.getElementById('bookBody');
  var rows = (r.data && r.data.bookings) || [];
  if (!rows.length) { body.innerHTML = '<tr><td colspan="7" style="padding:20px;color:var(--muted)">Brak rezerwacji.</td></tr>'; return; }
  body.innerHTML = rows.map(function (b) {
    var actions = '';
    if (b.status === 'confirmed' || b.status === 'pending_email') {
      actions += '<button class="mini-btn ok" onclick="setStatus(\'' + b.id + '\',\'done\')">Zrealizowana</button>';
      actions += '<button class="mini-btn danger" onclick="setStatus(\'' + b.id + '\',\'cancelled\')">Anuluj</button>';
    }
    return '<tr>' +
      '<td>' + esc(b.date) + '</td>' +
      '<td>' + esc(b.time) + '</td>' +
      '<td>' + esc(b.firstName + ' ' + b.lastName) + '</td>' +
      '<td>' + esc(b.email) + '</td>' +
      '<td>' + esc(b.topic || '-') + '</td>' +
      '<td><span class="badge ' + esc(b.status) + '">' + esc(STATUS_PL[b.status] || b.status) + '</span></td>' +
      '<td>' + actions + '</td>' +
      '</tr>';
  }).join('');
}

async function setStatus(id, status) {
  var r = await apiPost('/api/admin/bookings/' + id + '/status', { status: status });
  if (r.ok) { toast('Zaktualizowano status.', 'ok'); loadBookings(); }
  else toast((r.data && r.data.error) || 'B\u0142\u0105d.', 'err');
}

async function loadReviews() {
  var r = await apiGet('/api/admin/reviews');
  var body = document.getElementById('revBody');
  var rows = (r.data && r.data.reviews) || [];
  if (!rows.length) { body.innerHTML = '<tr><td colspan="5" style="padding:20px;color:var(--muted)">Brak opinii.</td></tr>'; return; }
  body.innerHTML = rows.map(function (rv) {
    var actions = '';
    if (!rv.approved) actions += '<button class="mini-btn ok" onclick="approveRev(\'' + rv.id + '\')">Zatwierd\u017a</button>';
    actions += '<button class="mini-btn danger" onclick="deleteRev(\'' + rv.id + '\')">Usu\u0144</button>';
    var status = rv.approved ? '<span class="badge confirmed">Opublikowana</span>' : '<span class="badge pending_email">Oczekuje</span>';
    return '<tr>' +
      '<td>' + '\u2605'.repeat(rv.rating || 5) + '</td>' +
      '<td>' + esc(rv.name) + (rv.company ? '<br><span style="color:var(--muted);font-size:.82rem">' + esc(rv.company) + '</span>' : '') + '</td>' +
      '<td style="max-width:320px">' + esc(rv.text) + '</td>' +
      '<td>' + status + '</td>' +
      '<td>' + actions + '</td>' +
      '</tr>';
  }).join('');
}

async function approveRev(id) {
  var r = await apiPost('/api/admin/reviews/' + id + '/approve', {});
  if (r.ok) { toast('Opinia opublikowana.', 'ok'); loadReviews(); }
}
async function deleteRev(id) {
  var r = await apiPost('/api/admin/reviews/' + id + '/delete', {});
  if (r.ok) { toast('Opinia usuni\u0119ta.', 'ok'); loadReviews(); }
}

document.getElementById('loginForm').addEventListener('submit', async function (e) {
  e.preventDefault();
  var box = document.getElementById('loginMsg'); box.innerHTML = '';
  var res = await apiPost('/api/admin/login', {
    email: document.getElementById('aEmail').value,
    password: document.getElementById('aPass').value,
  });
  if (res.ok) showDash(document.getElementById('aEmail').value);
  else box.innerHTML = '<div class="msgbox err">' + esc((res.data && res.data.error) || 'Nie uda\u0142o si\u0119 zalogowa\u0107.') + '</div>';
});

checkAuth();
