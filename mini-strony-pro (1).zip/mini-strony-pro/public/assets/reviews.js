// Obsluga strony Opinie: lista + wysylanie opinii.
(function () {
  var list = document.getElementById('reviewsList');

  function esc(s) { var d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; }
  function stars(n) { n = Math.max(1, Math.min(5, n || 5)); return '\u2605'.repeat(n) + '\u2606'.repeat(5 - n); }
  function initials(name) { return (name || '?').trim().charAt(0).toUpperCase(); }

  async function load() {
    var r = await apiGet('/api/reviews');
    var reviews = (r.data && r.data.reviews) || [];
    if (!reviews.length) {
      list.innerHTML = '<p style="color:var(--muted)">Nie ma jeszcze opinii. B\u0105d\u017a pierwsz\u0105 osob\u0105, kt\u00f3ra j\u0105 doda!</p>';
      return;
    }
    list.innerHTML = reviews.map(function (rv) {
      return '<div class="review">' +
        '<div class="stars">' + stars(rv.rating) + '</div>' +
        '<div class="txt">\u201e' + esc(rv.text) + '\u201d</div>' +
        '<div class="who"><div class="ava">' + esc(initials(rv.name)) + '</div>' +
        '<div><b>' + esc(rv.name) + '</b>' + (rv.company ? '<span>' + esc(rv.company) + '</span>' : '') + '</div></div>' +
        '</div>';
    }).join('');
  }

  var form = document.getElementById('reviewForm');
  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    var box = document.getElementById('reviewMsg');
    box.innerHTML = '';
    var payload = {
      name: document.getElementById('rName').value,
      company: document.getElementById('rCompany').value,
      rating: (document.querySelector('input[name=rating]:checked') || {}).value,
      text: document.getElementById('rText').value,
    };
    var res = await apiPost('/api/reviews', payload);
    if (res.ok) {
      box.innerHTML = '<div class="msgbox ok">' + esc(res.data.message || 'Dzi\u0119kujemy za opini\u0119!') + '</div>';
      form.reset();
      toast('Dzi\u0119kujemy! Opinia czeka na akceptacj\u0119.', 'ok');
    } else {
      box.innerHTML = '<div class="msgbox err">' + esc((res.data && res.data.error) || 'Wyst\u0105pi\u0142 b\u0142\u0105d.') + '</div>';
    }
  });

  load();
})();
